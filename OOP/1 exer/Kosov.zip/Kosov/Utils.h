#pragma once
#include <string>
#include <iostream>
using namespace std;

void cin_clear(string title);
int check_id(int id, int size);
